package com.Msite.TestScripts;

import org.testng.Reporter;
import org.testng.annotations.Test;

import com.Msite.Pages.SearchInAmazonPage;
import com.Msite.Pages.SearchInFlipkart;




public class ComparePricePageTest extends BaseClass
{
	@Test (priority=1)
	public void verifyLesserProductValue() 
	{
		
		Reporter.log("User Logged In successfully");
		SearchInAmazonPage sia=new SearchInAmazonPage(driver);
		SearchInFlipkart sf = new SearchInFlipkart(driver);
		Reporter.log("Click on Search");
		sia.searchForProductInAmazon();
		sia.verifyAvailableElements();
		sia.openSearchedResult();
		float amazonPrice=sia.getPrice();
		sf.launchFlikartWebsite();
		sf.searchForProductInFlipkart();
		sf.openSearchedResult();
		float flipkartPrice=sf.getPrice();
		sf.compareAndGiveLesserOne(amazonPrice, flipkartPrice);
		
	}

}
