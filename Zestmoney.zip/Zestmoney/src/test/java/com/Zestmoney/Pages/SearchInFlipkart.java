package com.Msite.Pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.Msite.TestScripts.BaseClass;

public class SearchInFlipkart extends BaseClass
{

	public static Logger logger;
	public SearchInFlipkart(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	String mainwindow="";
	String PriceText="";
	
	public void launchFlikartWebsite() 
	{
		driver.get("https://www.flipkart.com/");
		waitForSeconds(4);
		FindElement("xpath", "//div[@class='_3Njdz7']//button").click();
		waitForSeconds(5);
	}
	
	public void searchForProductInFlipkart() 
	{
		try 
		{
			FindElement("xpath", "//input[contains(@placeholder,'Search for products, brands and more')]").sendKeys("iPhone 11 (64GB) - White");
			waitForSeconds(3);
			FindElement("xpath", "//button[contains(@type,'submit')]//*[local-name()='svg']").click();
			waitForSeconds(3);
		}
		catch(Exception e)
		{
			e.getMessage();
		}
	}
	
	  public void openSearchedResult()
	  {
		  mainwindow=driver.getWindowHandle();
		  FindElement("xpath", "//div[@data-id='MOBFKCTSHAWGGFHM']//div[@class='_3BTv9X']").click();
		  waitForSeconds(5);  
	  }   

	  public float getPrice()
	  {
		  SwitchTabs(2);
		  PriceText=FindElement("xpath", "//div[@class='_1vC4OE _3qQ9m1']").getText();
	      String substr = PriceText.substring(1, PriceText.length());
	      String str=substr.replace(",","");
	      return  Float.valueOf(str).floatValue();
	  }
	  
	public void compareAndGiveLesserOne(float amazonvalue,float flipkartvalue) 
	{
		if(amazonvalue>flipkartvalue)
			System.out.println(flipkartvalue);
		else
			System.out.println(amazonvalue);
		
	}
	
}
