package com.Msite.Pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.Msite.TestScripts.BaseClass;


public class SearchInAmazonPage extends BaseClass
{
	
	public static Logger logger;
	public SearchInAmazonPage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="twotabsearchtextbox")
	WebElement amazonSearchBox;
	
	@FindBy(xpath="//span[@id='priceblock_dealprice']")
	WebElement discountPriceText;
	
	String mainwindow="";
	String PriceText="";
	    	 
	public void searchForProductInAmazon() 
	{
		try 
		{
			amazonSearchBox.sendKeys("iPhone 11 (64GB) - White");
			waitForSeconds(3);
			FindElement("xpath", "//form[@name='site-search']//input[@type='submit']").click();
			waitForSeconds(3);
		}
		catch(Exception e)
		{
			e.getMessage();
		}
	}
	
 
	public void verifyAvailableElements() 
	{
		Assert.assertTrue(isElementPresentByXpath("//div[@id='nav-logo']"), "Amazon.in Logo in misisng in the page");
		Assert.assertTrue(isElementPresentByXpath("//span[@class='icp-nav-link-inner']"), "Country Logo in misisng in the page");
		Assert.assertTrue(isElementPresentByXpath("//a[@id='nav-link-accountList']"), "Account Login Link in misisng in the page");
		Assert.assertTrue(isElementPresentByXpath("//a[@id='nav-orders']"), "Returns and Order List Link in misisng in the page");
		Assert.assertTrue(isElementPresentByXpath("//a[@id='nav-link-prime']"), "Amazon Prime Login Link Logo in misisng in the page");
		
	}
	
  public void openSearchedResult()
  {
	  mainwindow=driver.getWindowHandle();
	  FindElement("xpath", "//div[@class='s-main-slot s-result-list s-search-results sg-row']//div[@class='a-section a-spacing-none']").click();
	  waitForSeconds(5);  
  }   
  
  public float getPrice()
  {
	  SwitchTabs(1);
	  PriceText=FindElement("xpath", "//span[@class='priceBlockStrikePriceString a-text-strike']").getText();
	  if(isElementPresent(discountPriceText))
	  {
	  PriceText=discountPriceText.getText();
	 }
      String substr = PriceText.substring(2, 11);
      String str=substr.replace(",","");
      return  Float.valueOf(str).floatValue();
  }
  
  
  
}
